from CRC import CRCencoder, Polynomial
import pytest

@pytest.fixture
def CRC():
    return CRCencoder()

def test_setMessage(CRC):
    msg ='10111010'
    CRC.setMessage(msg)
    assert CRC.msg == Polynomial(msg)

def test_createDividentPoly(CRC):
    divident =CRC.createDivident(4)
    assert divident == Polynomial('10001')

def test_findGeneratingPoly(CRC):  
    msg ='10111010'
    CRC.setMessage(msg)  

    CRC.findGeneratingPoly(4)    
    assert isinstance(CRC.gPolys[0],Polynomial)

def test_encode(CRC):
    msg ='101101'
    CRC.setMessage(msg)
    CRC.gPoly = Polynomial('1011') 
    encodedMsg=CRC.encode()
    assert encodedMsg == Polynomial('101101011')

def test_checkForError_correct(CRC):
    msg = '101101011'
    CRC.setMessage(msg)
    CRC.gPoly = Polynomial('1011') 
    assert Polynomial('0') == CRC.checkForError()

def test_checkForError_incorrect(CRC):
    msg = '101111011'
    CRC.setMessage(msg)
    CRC.gPoly = Polynomial('1011') 
    assert Polynomial('110') == CRC.checkForError()

def test_decode_correct(CRC):
    msg = '101101011'
    CRC.setMessage(msg)
    CRC.gPoly = Polynomial('1011')
    decodedMsg = CRC.decode()
    assert decodedMsg == Polynomial('101101')

def test_findError(CRC):
    msg = '101111011'
    CRC.setMessage(msg)
    CRC.gPoly = Polynomial('1011')
    reminder = CRC.checkForError()
    assert 4 == CRC.findError(reminder)

def test_findError2(CRC):
    msg = '101100011'
    CRC.setMessage(msg)
    CRC.gPoly = Polynomial('1011')
    reminder = CRC.checkForError()
    assert 3 == CRC.findError(reminder)

def test_decode_incorrect(CRC):
    msg = '101111011'
    CRC.setMessage(msg)
    CRC.gPoly = Polynomial('1011')
    decodedMsg = CRC.decode()
    assert decodedMsg == Polynomial('101101')

def test_decode_incorrectFindIndexOfError(CRC):
    msg = '101101001'
    CRC.setMessage(msg)
    CRC.gPoly = Polynomial('1011')
    decodedMsg = CRC.decode()
    assert 1 == CRC.errorOn


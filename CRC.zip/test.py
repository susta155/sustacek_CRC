from operator import xor
import numpy as np

x = '0'

y = int(not x)

print(y)